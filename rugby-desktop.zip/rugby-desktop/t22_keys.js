// Barcha hotkeylarni TIZIMLI tekshirish.
//
// Muammo tarixi: bir harf ikki joyda ishlatilsa, birinchisi `return` qiladi
// va IKKINCHISI HECH QACHON ishga tushmaydi. Shu tariqa:
//   G — polygon oldin, grid keyin  → grid ishlamasdi
//   T — trim oldin, text keyin     → text ishlamasdi
//
// Bu test har harfni butun fayl bo'ylab qidiradi va bir nechta joyda
// uchrasa ogohlantiradi.

const fs=require('fs');
const APP='/mnt/user-data/outputs/rugby-desktop/app/';
const ks=fs.readFileSync(APP+'js/ui/input-keys.js','utf8');
let fails=0;
const t=(n,c,e)=>{console.log((c?'  ok   ':'  FAIL ')+n+(e&&!c?'   → '+e:'')); if(!c)fails++;};

// Klavish qaysi KONTEKSTDA ishlashini aniqlaymiz — bir harf turli
// shartlar ostida turli ish qilishi MUMKIN va bu xato emas.
function contextAt(pos){
  const before = ks.slice(Math.max(0,pos-1400), pos);
  if(/\(e\.ctrlKey\|\|e\.metaKey\)[^\n]*\/\^\[cxvd\]/.test(before)) return 'Ctrl+key';
  const iDraw = before.lastIndexOf("drawTool==='line' && currentDraw");
  const iTool = before.lastIndexOf('// Tool hotkeys');
  if(iDraw > iTool) return 'chizish paytida';
  return 'asosiy';
}
const lineOf = pos => ks.slice(0,pos).split('\n').length;

// --- barcha bir-harfli hotkeylarni o'rni bilan yig'amiz ---
const hits=[];
// drawKeys jadvalidan
const dk=ks.match(/const drawKeys = \{([^}]+)\}/);
if(dk){
  const pos=ks.indexOf(dk[0]);
  dk[1].split(',').forEach(pair=>{
    const m=pair.match(/(\w):\s*'(\w+)'/);
    if(m) hits.push({key:m[1], what:'draw:'+m[2], pos, ctx:'asosiy'});
  });
}
// alohida if(k==='x') shartlaridan
const re=/if\(k==='([a-z])'(?:\s*&&\s*([^)]*))?\)\s*\{?\s*e\.preventDefault\(\);\s*([^\n]*)/g;
let m;
while((m=re.exec(ks))!==null){
  hits.push({key:m[1], guard:(m[2]||'').trim(),
             what:(m[3]||'').trim().slice(0,52), pos:m.index, ctx:contextAt(m.index)});
}

console.log('=== Aniqlangan bir-harfli hotkeylar ===\n');
const byKey={};
hits.forEach(h=>{ (byKey[h.key]=byKey[h.key]||[]).push(h); });
Object.keys(byKey).sort().forEach(k=>{
  const list=byKey[k];
  const tag = list.length>1 ? '  ← '+list.length+' joyda' : '';
  console.log('  '+k.toUpperCase()+tag);
  list.forEach(h=>console.log('       '+String(lineOf(h.pos)).padStart(4)+'-qator  '+
    h.ctx.padEnd(16)+(h.guard?'['+h.guard+'] ':'')+h.what));
});

console.log('\n=== To\'qnashuvlar ===\n');
// Bir harf ikki joyda bo'lsa: guard (shart) bo'lsa MAYLI, bo'lmasa XATO
let clashes=0;
Object.keys(byKey).sort().forEach(k=>{
  const list=byKey[k].slice().sort((a,b)=>a.pos-b.pos);
  if(list.length<2) return;
  // Haqiqiy to'qnashuv = BIR XIL kontekstda, guardsiz, ikki marta.
  // Turli kontekst (Ctrl+key / chizish paytida / asosiy) — bu XATO EMAS,
  // chunki ular bir vaqtda faol bo'lmaydi.
  const groups={};
  list.forEach(h=>{ if(!h.guard) (groups[h.ctx]=groups[h.ctx]||[]).push(h); });
  Object.keys(groups).forEach(ctx=>{
    const g=groups[ctx];
    if(g.length<2) return;
    clashes++;
    console.log('  ✗ '+k.toUpperCase()+' — "'+ctx+'" kontekstida '+g.length+' marta:');
    console.log('      ishlaydi  : '+lineOf(g[0].pos)+'-qator  '+g[0].what);
    g.slice(1).forEach(h=>console.log('      ISHLAMAYDI: '+lineOf(h.pos)+'-qator  '+h.what));
  });
});
t('soya soluvchi to\'qnashuv yo\'q', clashes===0, clashes+' ta topildi');

console.log('\n=== Muhim hotkeylar mavjudmi? ===\n');
const need=[
  ['polygon', /g:\s*'polygon'/],
  ['grid (H)', /k==='h'[\s\S]{0,80}toggleGrid/],
  ['trim (T)', /k==='t'[\s\S]{0,80}startTrim/],
  ['matn (B)', /k==='b'[\s\S]{0,80}toggleTextTool/],
  ['offset (O)', /k==='o'[\s\S]{0,80}startOffset/],
  ['fillet (F)', /k==='f'[\s\S]{0,220}startFillet/],
  ['maydon (Shift+A)', /e\.shiftKey[\s\S]{0,120}toLowerCase\(\)==='a'[\s\S]{0,120}reportArea/],
  ['joylashtirish (Ctrl+V)', /k==='v'[\s\S]{0,220}startPastePlace/],
];
need.forEach(([nm,re])=>t(nm, re.test(ks)));

console.log('\n=== G va T endi to\'g\'ri ishlaydimi? ===\n');
// G bosilganda nima bo'ladi — birinchi mos keladigan shoxobcha
function firstMatch(key){
  // "asosiy" kontekstda (hech qanday asbob faol emas) qaysi biri ishlaydi
  const list=(byKey[key]||[]).filter(h=>h.ctx==='asosiy').sort((a,b)=>a.pos-b.pos);
  return list.length ? list[0].what : '(yo\'q)';
}
t('G → polygon (grid emas)', /polygon/.test(firstMatch('g')), firstMatch('g'));
t('T → trim (matn emas)', /Trim|trim/.test(firstMatch('t')), firstMatch('t'));
t('H → grid', /toggleGrid/.test(firstMatch('h')), firstMatch('h'));
t('B → matn', /toggleTextTool/.test(firstMatch('b')), firstMatch('b'));

console.log('\n=== UI tooltiplari to\'g\'rimi? ===\n');
const html=fs.readFileSync(APP+'index.html','utf8');
t('Matn tugmasida [B]', /matn[^"]*\[B\]/i.test(html));
t('Katak yozuvida [H]', /Kataklarni[^"]*\[H\]/i.test(html));
t('Trim tugmasida [T] saqlandi', /Trim\/Extend[^"]*\[T\]/.test(html));
t('theme.js xabarida [H]', /\[H\]/.test(fs.readFileSync(APP+'js/ui/theme.js','utf8')));

console.log('\n'+(fails?'❌ '+fails+' ta yiqildi':'✅ Barcha testlar o\'tdi'));
process.exit(fails?1:0);
