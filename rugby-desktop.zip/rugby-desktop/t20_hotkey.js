const fs=require('fs');
const APP='/mnt/user-data/outputs/rugby-desktop/app/';
let fails=0;
const t=(n,c,e)=>{console.log((c?'  ok   ':'  FAIL ')+n+(e&&!c?'   → '+e:'')); if(!c)fails++;};
const ks=fs.readFileSync(APP+'js/ui/input-keys.js','utf8');

console.log('=== Shift+A tartibi ===\n');

const iArea = ks.indexOf("e.key.toLowerCase()==='a'");
const iDraw = ks.indexOf("appMode==='draw' && drawTool==='line' && currentDraw");
const iTool = ks.indexOf("// Tool hotkeys");

t('Shift+A bloki topildi', iArea > 0);
t('chizish bloki topildi', iDraw > 0);
t('Shift+A chizish blokidan OLDIN', iArea < iDraw,
  'area@'+iArea+' vs draw@'+iDraw);
t('Shift+A asbob hotkeylaridan OLDIN', iTool < 0 || iArea < iTool,
  'area@'+iArea+' vs tools@'+iTool);

console.log('\n=== Chizish bloki Shift ni hisobga oladimi? ===\n');
const drawBlock = ks.slice(iDraw-200, iDraw+400);
t('chizish bloki !e.shiftKey tekshiradi', /!e\.shiftKey/.test(drawBlock),
  'Shift+A hali arc ga tushadi');

console.log('\n=== Klavish ishlovini simulyatsiya ===\n');
// input-keys.js dagi shartlarni to'g'ridan-to'g'ri tekshiramiz
function wouldFireArea(state){
  const e=state.e;
  // 199-qatordagi shart
  return !!(e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey &&
            e.key.toLowerCase()==='a');
}
function wouldFireArc(state){
  const e=state.e;
  return !!(state.appMode==='draw' && state.drawTool==='line' && state.currentDraw &&
            !e.ctrlKey && !e.altKey && !e.metaKey && !e.shiftKey &&
            e.key.toLowerCase()==='a');
}
const cases=[
  ['Bone edit + Shift+A',      {appMode:'edit', drawTool:'none', currentDraw:null,
                                e:{key:'A', shiftKey:true}},  'area'],
  ['Chizish (asbobsiz) Shift+A',{appMode:'draw', drawTool:'none', currentDraw:null,
                                e:{key:'A', shiftKey:true}},  'area'],
  ['Chiziq CHIZAYOTGANDA Shift+A', {appMode:'draw', drawTool:'line', currentDraw:{},
                                e:{key:'A', shiftKey:true}},  'area'],
  ['Chiziq chizayotganda oddiy A', {appMode:'draw', drawTool:'line', currentDraw:{},
                                e:{key:'a', shiftKey:false}}, 'arc'],
  ['Ctrl+Shift+A (boshqa buyruq)', {appMode:'edit', drawTool:'none', currentDraw:null,
                                e:{key:'A', shiftKey:true, ctrlKey:true}}, 'hech biri'],
];
cases.forEach(([nm,st,exp])=>{
  const area=wouldFireArea(st), arc=wouldFireArc(st);
  const got = area ? 'area' : (arc ? 'arc' : 'hech biri');
  t(nm+' → '+exp, got===exp, 'olindi: '+got);
});

console.log('\n=== Boshqa Shift kombinatsiyalari buzilmadimi? ===\n');
t('Ctrl+Shift+S (Saqlash…) saqlanib qoldi', /e\.shiftKey\) saveProjectAs\(\)/.test(ks));
t('Shift+G (Ungroup) saqlanib qoldi', /e\.shiftKey\) ungroupSelected\(\)/.test(ks));
t('Shift+F (Chamfer) saqlanib qoldi', /e\.shiftKey \? 'chamfer'/.test(ks));
t('Ctrl+Shift+Z (Redo) saqlanib qoldi', /e\.shiftKey && e\.key\.toLowerCase\(\)==='z'/.test(ks));

// Shift+A ular bilan to'qnashmaydimi?
const others=[['s','Ctrl+Shift+S'],['g','Shift+G'],['f','Shift+F'],['z','Ctrl+Shift+Z']];
others.forEach(([key,nm])=>{
  const fires = wouldFireArea({e:{key:key, shiftKey:true}});
  t(nm+' Shift+A ni ishga tushirmaydi', !fires);
});

console.log('\n'+(fails?'❌ '+fails+' ta yiqildi':'✅ Barcha testlar o\'tdi'));
process.exit(fails?1:0);
