# RUGBY — CNC Corner Editor · Desktop

Windows uchun bitta `.exe` o'rnatuvchi. Blender kabi: bitta fayl, o'rnatish
sehrgari, kerakli papkalarga o'zi ajraladi, yorliqlar va o'chirgich yaratadi.

![splash](PREVIEW-splash.png)

---

## Tez boshlash

**Node.js 18+** kerak — <https://nodejs.org> (LTS). Boshqa hech narsa emas.

```bash
npm install     # bir marta (~200 MB Electron yuklab olinadi)
npm start       # sinab ko'rish
npm run dist    # O'RNATUVCHI yasash
```

Natija:

```
dist/Rugby-1.0.0-Setup.exe        ← bitta fayl, tarqatish uchun shu
```

O'rnatmasdan ishlaydigan variant kerak bo'lsa:

```bash
npm run dist:portable   → dist/Rugby-1.0.0-Portable.exe
npm run dist:both       → ikkalasi ham
```

---

## Nima qilingan

### 1. Splash — to'liq ekran, atlas foni

Dastur ochilishida butun ekranni egallaydigan splash chiqadi:

- **Fon** — "mat'odek tovlanuvchi" oqib yuruvchi atlas. Bu **video emas**,
  real vaqtda hisoblanadigan **WebGL shader**.
- **Logo** — yumshoq kattalashib chiqadi, ustidan yaltiroq nur o'tadi
- **RUGBY** so'z belgisi pastdan ko'tarilib chiqadi
- Yuklanish chizig'i va holat matni
- **Esc** yoki bosish — o'tkazib yuborish

**Nega video emas, shader?**

| | Video | Shader |
|---|---|---|
| 4K / ultrawide ekran | cho'ziladi yoki pikselga aylanadi | har ekranda **o'z o'lchamida** chiziladi |
| Loop | har 2 sekundda **sakrash** xavfi | chegara **yo'q**, cheksiz oqadi |
| Hajm | 1–3 MB | **~4 KB** |
| Rangni o'zgartirish | qayta render qilish kerak | ikkita raqam |

Shader `splash.html` ichida, `FS` o'zgaruvchisida. WebGL bo'lmasa avtomatik
CSS gradientga tushadi.

### 2. Ishchi oynada logo

Chap yuqori burchakda — logo belgisi + **RUGBY** + "CNC Corner Editor".
Ajratuvchi chiziq bilan, boshqa pro dasturlardagidek.

### 3. Papkada ikona

`.exe`, yorliqlar, Boshlash menyusi va vazifalar paneli — hamma joyda logo.
Ikona 16 px dan 256 px gacha barcha o'lchamlarda toza chiqadi.

### 4. `.dbe` fayl assotsiatsiyasi

O'rnatgandan keyin `.dbe` loyiha fayllari **Rugby ikonasini oladi** va ikki
marta bosilganda to'g'ridan-to'g'ri dasturda ochiladi.

### 5. Ctrl+S to'liq ishlaydi

Brauzer versiyasida `file://` cheklovi bor edi — papka tanlab bo'lmasdi.
`main.js` maxsus `app://` protokolini "secure" deb ro'yxatdan o'tkazadi,
shuning uchun desktopda **Ctrl+S haqiqiy papka tanlaydi va fayl ustiga yozadi**.

---

## Papka tuzilmasi

```
rugby-desktop/
├── main.js              Electron asosiy jarayoni (oynalar, protokol, fayl)
├── preload.js           asosiy oyna ↔ tizim ko'prigi
├── preload-splash.js    splash ↔ tizim ko'prigi
├── splash.html          to'liq ekran splash + atlas shaderi
├── package.json         electron-builder sozlamalari
│
├── app/                 ILOVANING O'ZI (34 modul)
│   ├── index.html
│   ├── css/style.css
│   ├── assets/logo-mark.png
│   └── js/  geometry · model · io · tools · ui
│
├── assets/              splash va oyna uchun brend fayllari
│   ├── icon-512.png · icon-256.png · icon-1024.png
│   ├── wordmark-light.png   (to'q fon uchun — oq)
│   ├── wordmark-dark.png    (oq fon uchun — navy)
│   └── ball-512.png         (to'p, kvadratsiz)
│
└── build/               o'rnatuvchi resurslari
    ├── icon.ico         (16/24/32/48/64/128/256 — hammasi ichida)
    └── icon.png         (512×512)
```

---

## O'rnatuvchi nima qiladi

| | |
|---|---|
| Turi | NSIS sehrgar, **bitta `.exe`** |
| Papka tanlash | ✅ foydalanuvchi o'zgartira oladi |
| Standart joy | `%LOCALAPPDATA%\Programs\Rugby` |
| Administrator | **kerak emas** |
| Ish stoli yorlig'i | ✅ |
| Boshlash menyusi | ✅ |
| O'chirish | ✅ "Ilovalar va imkoniyatlar" ro'yxatida |
| `.dbe` assotsiatsiyasi | ✅ |
| O'rnatgach ishga tushirish | ✅ |

**Barcha foydalanuvchilar uchun `Program Files` ga o'rnatilsin desangiz**
(Blender kabi, lekin administrator so'raydi) — `package.json` da:

```json
"nsis": { "perMachine": true }
```

---

## Sozlash mumkin bo'lgan joylar

### Splash davomiyligi

`main.js`, 21-qator:

```js
const MIN_SPLASH_MS = 2600;   // millisekund
```

Splash **kamida** shuncha turadi, lekin dastur hali tayyor bo'lmasa —
tayyor bo'lgunicha kutadi. Shuning uchun sekin kompyuterda oq ekran ko'rinmaydi.

### Fon ranglari

`splash.html` ichida, shaderda:

```glsl
vec3 navy = vec3(0.0902, 0.1490, 0.2392);   // #17263D
vec3 cyan = vec3(0.3647, 0.8784, 0.9961);   // #5DE0FE
```

### Tovlanish tezligi va zichligi

```glsl
float sheen  = pow(0.5 + 0.5*sin(h*12.0 + t*1.10), 7.0);
//                              ↑ lenta soni   ↑ tezlik   ↑ keskinlik
```

- `12.0` kattaroq → ko'proq, ingichkaroq lentalar
- `1.10` kattaroq → tezroq oqadi
- `7.0` kattaroq → lentalar keskinroq, kontrast yuqori

### Burma yo'nalishi

```glsl
vec2 pr = vec2(p.x*0.94 - p.y*0.34, p.x*0.34 + p.y*0.94);   // ~20°
```

`0.94 / 0.34` — bu `cos(20°) / sin(20°)`. Boshqa burchak uchun mos
qiymatlarni qo'ying.

### Versiya raqami

`package.json` dagi `"version"` — splashda va o'rnatuvchi nomida avtomatik
ko'rinadi.

---

## Brend ranglari

| | HEX | Qayerda |
|---|---|---|
| Cyan | `#5DE0FE` | logo foni, urg'u, tikuvlar |
| Navy | `#17263D` | to'p, matn (oq fonda) |
| Fon | `#0B1220` | dastur interfeysi |

---

## Muammolar

**`npm install` xato beradi** — internetni tekshiring. Korporativ tarmoqda:
`npm config set proxy http://...`

**Splash oq/qora chiqadi** — video kartada WebGL yo'q. Dastur avtomatik CSS
gradientga tushadi, ishlashiga xalaqit bermaydi. Drayverni yangilang.

**Splash qotib qoladi** — 15 soniyadan keyin majburan yopiladi (`main.js`).
Sabab: asosiy oyna yuklanmagan. `npm start` bilan ishga tushirib,
`Ctrl+Shift+I` da konsolni ko'ring.

**Windows "noma'lum nashriyot" deb ogohlantiradi** — bu normal, kod imzosi
(code signing) sertifikati yo'qligi uchun. Foydalanuvchi
"More info → Run anyway" bosadi. Sertifikat pullik (yiliga ~$200);
olsangiz `package.json` ga `"win": { "certificateFile": ... }` qo'shiladi.

**Ikonalar eski ko'rinadi** — Windows ikona keshini tozalang:
```
ie4uinit.exe -show
```

---

## Testlar

Ilovaning o'z testlari `app/` bilan birga ishlaydi:

```
test_after.js       geometry, snap, join, nesting
test_dim_text.js    o'lchov joylashuvi, halo, matn asbobi, DXF
test_move_file.js   Move+relief, chizish, fayl boshqaruvi
```

Uchalasi ham hozirgi kodda o'tadi.
