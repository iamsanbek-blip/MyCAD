/* ==========================================================================
   js/io/project.js
   Loyiha fayli (.dbe) saqlash/yuklash + fon rasm paneli

   Dogbone / T-Bone / Fillet / Chamfer Editor — modulli tuzilma.
   DIQQAT: fayllar index.html da QAT'IY tartibda yuklanadi. Tartibni
   o'zgartirmang — kod global scope'da ishlaydi va tartibga bog'liq.
   ========================================================================== */

// ===== PROJECT FILE (.dbe) =====
// A DXF cannot carry our layers, dogbone settings or dimensions, so the project
// format stores the full editing state and can be reopened exactly as left.
const PROJECT_VERSION = 1;
function buildProject(){
  return {
    format: 'dogbone-editor-project',
    version: PROJECT_VERSION,
    saved: new Date().toISOString(),
    units: 'mm',
    layers: JSON.parse(JSON.stringify(layers)),
    activeLayer: activeLayer,
    activeColor: activeColor,
    shapes: drawnLines.map(compactShape),
    refImages: refImages.map(r=>({id:r.id, src:r.src, x:r.x, y:r.y, wmm:r.wmm, hmm:r.hmm,
                                  aspect:r.aspect, rot:r.rot, opacity:r.opacity,
                                  visible:r.visible, locked:r.locked, name:r.name})),
    dimensions: JSON.parse(JSON.stringify(dimensions)),
    texts: (typeof texts!=='undefined') ? JSON.parse(JSON.stringify(texts)) : [],
    corners: corners.map(c=>({key:cornerKey(c), mode:c.mode, size:c.size, offset:c.offset||0,
                              tboneDir:c.tboneDir||'auto', tboneMirror:!!c.tboneMirror})),
    view: {scale:view.scale, ox:view.ox, oy:view.oy}
  };
}
function saveProject(){
  try{
    if(!drawnLines.length && !dimensions.length){
      document.getElementById('hint').innerHTML='Saqlanadigan chizma yo\'q.';
      return;
    }
    const txt = JSON.stringify(buildProject());
    downloadFile(txt, 'loyiha.dbe', 'application/json');
    document.getElementById('hint').innerHTML='Loyiha saqlandi ('+drawnLines.length+' shakl, '+layers.length+' qatlam).';
  }catch(err){
    alert('Loyihani saqlashda xatolik:\n'+err.message);
    console.error('saveProject:', err);
  }
}
function loadProject(text, fileName){
  let p;
  try{ p = JSON.parse(text); }
  catch(err){ alert('Loyiha faylini o\'qib bo\'lmadi (JSON xato):\n'+err.message); return false; }
  if(!p || p.format!=='dogbone-editor-project'){
    alert('Bu dogbone editor loyiha fayli emas.'); return false;
  }
  if(p.version > PROJECT_VERSION){
    alert('Bu loyiha yangiroq versiyada saqlangan. Ba\'zi narsalar to\'g\'ri ochilmasligi mumkin.');
  }
  try{
    layers = Array.isArray(p.layers) && p.layers.length
      ? JSON.parse(JSON.stringify(p.layers))
      : layers;
    if(p.activeLayer && layers.some(l=>l.id===p.activeLayer)) activeLayer = p.activeLayer;
    if(p.activeColor) activeColor = p.activeColor;
    polygons = [];
    refImages = [];
    (p.refImages||[]).forEach(src=>{
      const r=Object.assign({img:null}, src);
      refImages.push(r);
      attachRefImage(r);
    });
    activeRefId = refImages.length ? refImages[0].id : null;
    drawnLines = (p.shapes||[]).map(expandShape);
    dimensions = Array.isArray(p.dimensions) ? JSON.parse(JSON.stringify(p.dimensions)) : [];
    if(typeof texts!=='undefined') texts = Array.isArray(p.texts) ? JSON.parse(JSON.stringify(p.texts)) : [];
    const dropped = sanitizeDrawnLines();
    const settingsMap = new Map((p.corners||[]).map(s=>[s.key, s]));
    corners = [];
    detectCorners(settingsMap);
    if(p.view && isFinite(p.view.scale) && p.view.scale>0){
      view.scale=p.view.scale; view.ox=p.view.ox; view.oy=p.view.oy;
    } else { fitView(); }
    history=[]; historyIndex=-1; pushHistory();
    if(typeof renderLayerPanel==='function') renderLayerPanel();
    if(typeof renderColorPalette==='function') renderColorPalette();
    if(typeof renderRefPanel==='function') renderRefPanel();
    draw(); renderList(); renderDrawnList();
    const nm=document.getElementById('importedName');
    if(nm) nm.textContent='📄 '+(fileName||'loyiha.dbe');
    document.getElementById('hint').innerHTML='Loyiha ochildi: '+drawnLines.length+' shakl, '+
      dimensions.length+' o\'lchov, '+layers.length+' qatlam'+(dropped?(' — '+dropped+' ta buzuq element tashlandi'):'')+'.';
    return true;
  }catch(err){
    alert('Loyihani ochishda xatolik:\n'+err.message);
    console.error('loadProject:', err);
    return false;
  }
}
// ---- reference image panel ----
function renderRefPanel(){
  const box=document.getElementById('refList');
  if(!box) return;
  box.innerHTML='';
  if(!refImages.length){
    box.innerHTML='<div class="sub">Rasm yuklanmagan.</div>';
    return;
  }
  refImages.forEach(r=>{
    const row=document.createElement('div');
    row.className='corner-item'+(r.id===activeRefId?' sel':'');
    row.style.cssText='padding:6px;margin-bottom:6px;';
    const wmm=(isFinite(r.wmm)?r.wmm:200).toFixed(1);
    const hmm=(isFinite(r.hmm)?r.hmm:200).toFixed(1);
    row.innerHTML =
      '<div style="display:flex;align-items:center;gap:6px;">'+
        '<span style="flex:1;font-size:12px;'+(r.id===activeRefId?'color:var(--cyan);font-weight:600;':'')+'" data-pick="'+r.id+'">'+
          (r.name||'rasm')+' <span style="color:var(--text-dim);">'+wmm+'×'+hmm+' mm</span></span>'+
        '<button class="flipBtn" data-vis="'+r.id+'" title="Korinish">'+(r.visible?'👁':'🚫')+'</button>'+
        '<button class="flipBtn" data-lock="'+r.id+'" title="Qulf">'+(r.locked?'🔒':'🔓')+'</button>'+
        '<button class="flipBtn" data-del="'+r.id+'" title="Ochirish">✕</button>'+
      '</div>'+
      '<div style="display:flex;align-items:center;gap:4px;margin-top:5px;font-size:11px;color:var(--text-dim);">'+
        'Shaffoflik<input type="range" min="0" max="100" value="'+Math.round((r.opacity==null?0.5:r.opacity)*100)+'" data-op="'+r.id+'" style="flex:1;">'+
        '<span style="width:30px;text-align:right;">'+Math.round((r.opacity==null?0.5:r.opacity)*100)+'%</span>'+
      '</div>'+
      '<div style="display:flex;align-items:center;gap:4px;margin-top:5px;font-size:11px;color:var(--text-dim);flex-wrap:wrap;">'+
        '<label style="display:flex;align-items:center;gap:3px;">En<input type="number" data-w="'+r.id+'" value="'+wmm+'" min="0.1" step="1" style="width:64px;padding:2px;">mm</label>'+
        '<label style="display:flex;align-items:center;gap:3px;">Burchak<input type="number" data-rot="'+r.id+'" value="'+(r.rot||0)+'" step="1" style="width:54px;padding:2px;">&deg;</label>'+
      '</div>'+
      '<div style="display:flex;align-items:center;gap:4px;margin-top:4px;font-size:11px;color:var(--text-dim);">'+
        '<label style="display:flex;align-items:center;gap:3px;">X<input type="number" data-x="'+r.id+'" value="'+(r.x||0).toFixed(1)+'" step="1" style="width:64px;padding:2px;"></label>'+
        '<label style="display:flex;align-items:center;gap:3px;">Y<input type="number" data-y="'+r.id+'" value="'+(r.y||0).toFixed(1)+'" step="1" style="width:64px;padding:2px;"></label>'+
        '<button class="flipBtn" data-center="'+r.id+'" title="Chizma markaziga qoyish">⌖</button>'+
      '</div>';
    const q=s=>row.querySelector(s);
    q('[data-pick]').addEventListener('click', ()=>{ activeRefId=r.id; renderRefPanel(); draw(); });
    q('[data-vis]').addEventListener('click', ()=>{ r.visible=!r.visible; renderRefPanel(); draw(); });
    q('[data-lock]').addEventListener('click', ()=>{ r.locked=!r.locked; renderRefPanel(); draw(); });
    q('[data-del]').addEventListener('click', ()=>{ removeReference(r.id); });
    q('[data-op]').addEventListener('input', (e)=>{ r.opacity=parseFloat(e.target.value)/100; draw(); renderRefPanel(); });
    q('[data-w]').addEventListener('change', (e)=>{
      const v=parseFloat(e.target.value);
      if(isFinite(v)&&v>0){ r.wmm=v; r.hmm=v*(r.aspect||1); }
      draw(); renderRefPanel();
    });
    q('[data-rot]').addEventListener('change', (e)=>{
      const v=parseFloat(e.target.value); if(isFinite(v)) r.rot=v; draw(); renderRefPanel();
    });
    q('[data-x]').addEventListener('change', (e)=>{ const v=parseFloat(e.target.value); if(isFinite(v)) r.x=v; draw(); renderRefPanel(); });
    q('[data-y]').addEventListener('change', (e)=>{ const v=parseFloat(e.target.value); if(isFinite(v)) r.y=v; draw(); renderRefPanel(); });
    q('[data-center]').addEventListener('click', ()=>{
      // put the image over the middle of the current drawing (or the origin)
      let cx=0, cy=0, n=0;
      drawnLines.forEach(l=>l.points.forEach(p=>{ cx+=p.x; cy+=p.y; n++; }));
      if(n){ r.x=cx/n; r.y=cy/n; }
      draw(); renderRefPanel();
    });
    box.appendChild(row);
  });
}
function setRefEditMode(on){
  refEditMode = !!on;
  const b=document.getElementById('refEditBtn');
  if(b) b.classList.toggle('active', refEditMode);
  const hint=document.getElementById('hint');
  if(hint) hint.innerHTML = refEditMode
    ? 'Rasm tahriri YOQILDI — rasmni sudrab suring. Qulflangan rasm surilmaydi.'
    : 'Rasm tahriri o\'chirildi.';
  draw();
}
