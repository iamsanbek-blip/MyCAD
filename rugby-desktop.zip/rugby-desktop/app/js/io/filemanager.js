/* ==========================================================================
   js/io/filemanager.js
   Fayl boshqaruvi — New / Open / Save / Save As, hotkeylar bilan

   Dogbone / T-Bone / Fillet / Chamfer Editor — modulli tuzitma.
   DIQQAT: fayllar index.html da QAT'IY tartibda yuklanadi. Tartibni
   o'zgartirmang — kod global scope'da ishlaydi va tartibga bog'liq.
   ========================================================================== */

// ===== FAYL BOSHQARUVI =====
// Professional CAD dasturlaridagidek fayl oqimi:
//
//   Ctrl+N        Yangi          — hammasi tozalanadi
//   Ctrl+O        Ochish         — papkadan .dbe tanlash
//   Ctrl+S        Saqlash        — BIRINCHI marta joy so'raydi, keyin
//                                  har safar O'SHA fayl ustiga yozadi
//   Ctrl+Shift+S  Boshqacha saqlash — har safar joy so'raydi
//
// Papka tanlash File System Access API orqali ishlaydi (showSaveFilePicker).
// Bu API faqat http:// yoki https:// sahifalarda mavjud. Fayl file:// bilan
// ochilgan bo'lsa API yo'q — u holda oddiy "yuklab olish" ga tushadi va
// har safar brauzerning Downloads papkasiga tushadi (ustiga yozib bo'lmaydi).

let projectFileHandle = null;   // FileSystemFileHandle — brauzerda ustiga yozish
let projectFilePath   = null;   // to'liq yo'l — DESKTOP versiyada ustiga yozish
let projectFileName   = null;   // ko'rsatiladigan nom
let projectDirty      = false;  // oxirgi saqlashdan keyin o'zgarish bo'ldimi

// Desktop (Electron) rejimidamizmi? U yerda tizimning O'Z dialoglari ishlatiladi.
function onDesktop(){
  return !!(typeof window!=='undefined' && window.desktop && window.desktop.saveProjectAs);
}
function fsApiAvailable(){
  if(onDesktop()) return true;
  return typeof window!=='undefined' && typeof window.showSaveFilePicker === 'function';
}
function markProjectDirty(){
  projectDirty = true;
  updateFileBadge();

  // Saqlanmagan o'zgarishlar bo'lsa sahifani yopishdan oldin ogohlantirish
  window.addEventListener('beforeunload', (e)=>{
    if(!projectDirty || projectIsEmpty()) return;
    e.preventDefault();
    e.returnValue = '';
  });
}
function markProjectSaved(name, handle, fullPath){
  if(name)   projectFileName = name;
  if(handle!==undefined)   projectFileHandle = handle;
  if(fullPath!==undefined) projectFilePath   = fullPath;
  projectDirty = false;
  updateFileBadge();
}
function updateFileBadge(){
  const el = document.getElementById('currentFileName');
  if(!el) return;
  const name = projectFileName || 'nomsiz loyiha';
  el.textContent = name + (projectDirty ? ' •' : '');
  const bound = projectFilePath || projectFileHandle;
  el.title = bound
    ? ('Ctrl+S shu fayl ustiga yozadi:\n' + (projectFilePath || name))
    : (fsApiAvailable()
        ? 'Hali saqlanmagan — Ctrl+S joy so\'raydi'
        : 'file:// rejimida ustiga yozib bo\'lmaydi — Ctrl+S yuklab oladi');
}
function setHint(msg){
  const h=document.getElementById('hint'); if(h) h.innerHTML=msg;
}

// ---- YANGI ----
function newProject(){
  const has = drawnLines.length || dimensions.length || polygons.length ||
              (typeof texts!=='undefined' && texts.length);
  if(has && !confirm('Yangi loyiha boshlansinmi? Saqlanmagan o\'zgarishlar yo\'qoladi.')) return false;
  drawnLines=[]; dimensions=[]; polygons=[]; corners=[];
  if(typeof texts!=='undefined') texts=[];
  if(typeof refImages!=='undefined') refImages=[];
  if(typeof nestSheets!=='undefined') nestSheets=[];
  detectCorners();
  history=[]; historyIndex=-1; pushHistory();
  centerViewAtOrigin(1000);
  draw(); renderDrawnList(); renderList();
  if(typeof renderRefList==='function') renderRefList();
  markProjectSaved(null, null, null);
  projectFileName=null; updateFileBadge();
  setHint('Yangi loyiha boshlandi.');
  return true;
}

// ---- SAQLASH ----
function projectText(){ return JSON.stringify(buildProject()); }
function projectIsEmpty(){
  return !drawnLines.length && !dimensions.length &&
         !(typeof texts!=='undefined' && texts.length);
}

// Ctrl+S — mavjud faylga yozadi, bo'lmasa joy so'raydi
async function saveProjectQuick(){
  if(projectIsEmpty()){ setHint('Saqlanadigan chizma yo\'q.'); return false; }

  // DESKTOP: yo'l eslab qolingan bo'lsa — to'g'ridan-to'g'ri o'sha fayl ustiga
  if(onDesktop()){
    if(projectFilePath){
      try{
        const r = await window.desktop.saveProjectTo(projectFilePath, projectText());
        if(r){
          markProjectSaved(r.name, undefined, r.path);
          setHint('Saqlandi → <b>'+r.name+'</b> ('+drawnLines.length+' shakl).');
          return true;
        }
      }catch(err){
        alert('Saqlashda xatolik:\n'+err.message);
        return false;
      }
    }
    return saveProjectAs();
  }

  if(projectFileHandle){
    try{
      const w = await projectFileHandle.createWritable();
      await w.write(projectText());
      await w.close();
      markProjectSaved(projectFileName, projectFileHandle);
      setHint('Saqlandi → <b>'+projectFileName+'</b> ('+drawnLines.length+' shakl).');
      return true;
    }catch(err){
      if(err && err.name==='AbortError') return false;
      // ruxsat bekor qilingan bo'lishi mumkin — qaytadan joy so'raymiz
      projectFileHandle=null;
      return saveProjectAs();
    }
  }
  return saveProjectAs();
}

// Ctrl+Shift+S — har doim joy so'raydi
async function saveProjectAs(){
  if(projectIsEmpty()){ setHint('Saqlanadigan chizma yo\'q.'); return false; }
  const suggested = projectFileName || 'loyiha.dbe';

  // DESKTOP: tizimning o'z "Saqlash" oynasi
  if(onDesktop()){
    try{
      const r = await window.desktop.saveProjectAs(projectText(), projectFilePath || suggested);
      if(!r){ setHint('Saqlash bekor qilindi.'); return false; }
      markProjectSaved(r.name, undefined, r.path);
      setHint('Saqlandi → <b>'+r.name+'</b>. Endi <b>Ctrl+S</b> shu fayl ustiga yozadi.');
      return true;
    }catch(err){
      alert('Saqlashda xatolik:\n'+err.message);
      return false;
    }
  }

  if(fsApiAvailable()){
    try{
      const handle = await window.showSaveFilePicker({
        suggestedName: suggested,
        types: [{ description: 'Dogbone Editor loyihasi', accept: {'application/json': ['.dbe']} }],
      });
      const w = await handle.createWritable();
      await w.write(projectText());
      await w.close();
      markProjectSaved(handle.name || suggested, handle);
      setHint('Saqlandi → <b>'+projectFileName+'</b>. Endi <b>Ctrl+S</b> shu fayl ustiga yozadi.');
      return true;
    }catch(err){
      if(err && err.name==='AbortError'){ setHint('Saqlash bekor qilindi.'); return false; }
      alert('Saqlashda xatolik:\n'+err.message);
      return false;
    }
  }
  // Zaxira yo'l: file:// rejimida API yo'q — oddiy yuklab olish
  try{
    downloadFile(projectText(), suggested, 'application/json');
    markProjectSaved(suggested, null);
    setHint('Yuklab olindi → <b>'+suggested+'</b>. Papka tanlash uchun sahifani '+
            'http(s) server orqali oching (file:// da brauzer ruxsat bermaydi).');
    return true;
  }catch(err){
    alert('Saqlashda xatolik:\n'+err.message);
    return false;
  }
}

// ---- OCHISH ----
async function openProjectDialog(){
  // DESKTOP: tizimning o'z "Ochish" oynasi. Yo'l eslab qolinadi, shuning
  // uchun keyingi Ctrl+S AYNAN shu fayl ustiga yozadi.
  if(onDesktop() && window.desktop.openProject){
    try{
      const r = await window.desktop.openProject();
      if(!r) return false;
      loadProject(r.text, r.name);
      markProjectSaved(r.name, undefined, r.path);
      setHint('Ochildi → <b>'+r.name+'</b>. Ctrl+S shu fayl ustiga yozadi.');
      return true;
    }catch(err){
      alert('Faylni ochishda xatolik:\n'+err.message);
      return false;
    }
  }
  if(fsApiAvailable() && typeof window.showOpenFilePicker==='function'){
    try{
      const [handle] = await window.showOpenFilePicker({
        types: [{ description: 'Dogbone Editor loyihasi', accept: {'application/json': ['.dbe','.json']} }],
        multiple: false,
      });
      const file = await handle.getFile();
      const text = await file.text();
      loadProject(text, file.name);
      // handle saqlanadi — shu fayl ustiga Ctrl+S bilan yozish mumkin
      markProjectSaved(file.name, handle);
      return true;
    }catch(err){
      if(err && err.name==='AbortError') return false;
      alert('Faylni ochishda xatolik:\n'+err.message);
      return false;
    }
  }
  const inp = document.getElementById('projInput');
  if(inp) inp.click();
  return false;
}

// ---- import / export yorliqlari ----
function triggerImportDXF(){ const b=document.getElementById('fileInput'); if(b) b.click(); }
function triggerExportDXF(){ const b=document.getElementById('exportBtn'); if(b) b.click(); }

// ---- tugmalarni ulash ----
function wireFileManager(){
  const on = (id, fn) => { const b=document.getElementById(id); if(b) b.addEventListener('click', fn); };
  on('newProjBtn',    ()=>newProject());
  on('openProjBtn',   ()=>openProjectDialog());
  on('saveProjBtn',   ()=>saveProjectQuick());
  on('saveAsProjBtn', ()=>saveProjectAs());
  on('importBtn',     ()=>triggerImportDXF());

  // file:// rejimida papka tanlash mumkin emasligini bir marta eslatib qo'yamiz
  const note = document.getElementById('fileApiNote');
  if(note && !fsApiAvailable()){
    note.style.display='block';
    note.innerHTML = '⚠ Papka tanlash brauzer tomonidan faqat <b>http(s)</b> sahifalarda '+
                     'ruxsat etilgan. Hozir fayl <b>file://</b> orqali ochilgan, shuning uchun '+
                     'saqlash Downloads papkasiga tushadi.';
  }
  updateFileBadge();
}


// ---------------------------------------------------------------------------
//  Desktop (Electron): .dbe faylni ikki marta bosib ochish
//  Windows'da faylni bosganda dastur ishga tushadi va fayl mazmuni shu yerga
//  keladi. Brauzer versiyasida window.desktop bo'lmaydi — bu blok o'tkazib
//  yuboriladi.
// ---------------------------------------------------------------------------
if (typeof window !== 'undefined' && window.desktop && window.desktop.onOpenFile) {
  window.desktop.onOpenFile((text, name, fullPath) => {
    try {
      loadProject(text, name);
      markProjectSaved(name, undefined, fullPath || null);
      setHint('Ochildi: <b>' + name + '</b>' + (fullPath ? ' · Ctrl+S shu fayl ustiga yozadi' : ''));
    } catch (e) {
      alert('Faylni ochib bo\'lmadi: ' + e.message);
    }
  });
}
