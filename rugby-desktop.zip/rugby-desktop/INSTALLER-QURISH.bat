@echo off
chcp 65001 >nul
title Rugby - installer qurish
cd /d "%~dp0"

echo ============================================
echo   RUGBY - ornatuvchi (Setup.exe) qurish
echo ============================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo [XATO] Node.js topilmadi.
  echo.
  echo   1. https://nodejs.org saytiga kiring
  echo   2. LTS versiyasini yuklab, ornating
  echo   3. Kompyuterni qayta ishga tushiring
  echo   4. Shu faylni yana ishga tushiring
  echo.
  pause
  exit /b 1
)
for /f "tokens=*" %%v in (node -v) do echo Node.js topildi: %%v
echo.

if not exist node_modules (
  echo [1/2] Kutubxonalar yuklanmoqda... bu 3-10 daqiqa olishi mumkin.
  call npm install --no-audit --no-fund
  if errorlevel 1 goto fail
) else (
  echo [1/2] Kutubxonalar allaqachon ornatilgan - otkazib yuborildi.
)
echo.
echo [2/2] Installer qurilmoqda...
call npm run dist
if errorlevel 1 goto fail
echo.
echo ============================================
echo   TAYYOR!
echo   dist\Rugby-1.0.0-Setup.exe
echo ============================================
echo.
start "" "%cd%\dist"
pause
exit /b 0

:fail
echo.
echo [XATO] Qurish yakunlanmadi. Yuqoridagi xabarni oqing.
echo Kop uchraydigan sabab: internet uzilgan yoki antivirus tosgan.
echo.
pause
exit /b 1
